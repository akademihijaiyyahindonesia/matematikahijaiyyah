`timescale 1ns/1ps
module tb_cycles;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg start=0, finish=0; reg [511:0] key={64{8'h5a}};
  wire ready, idle, done; wire [255:0] mac;
  reg bv=0; reg [7:0] b=8'h00;
  hijaiyyah_hmac dut(.clk(clk),.rst_n(rst_n),.start(start),.key(key),.byte_valid(bv),.byte_in(b),
    .byte_ready(ready),.finish(finish),.idle(idle),.done(done),.mac(mac));
  integer n, sent, t0, lens[0:3], j;
  integer cyc=0; always @(posedge clk) cyc=cyc+1;
  initial begin
    lens[0]=1059; lens[1]=163; lens[2]=64; lens[3]=1024;
    #22 rst_n=1;
    for (j=0;j<4;j=j+1) begin
      n=lens[j]; @(negedge clk); while(!idle) @(negedge clk);
      start=1; @(negedge clk); start=0; t0=cyc; sent=0;
      // stream at full rate: byte_valid high whenever ready (combinational accept on posedge)
      while (sent<n) begin @(negedge clk); if (ready) begin bv=1; b=sent[7:0]; @(posedge clk); #1; sent=sent+1; end else bv=0; end
      bv=0; @(negedge clk); while(!ready) @(negedge clk); finish=1; @(negedge clk); finish=0;
      while(!done) @(negedge clk);
      $display("HMAC message %0d bytes: %0d clocks mac=%h", n, cyc-t0, mac);
    end
    $finish;
  end
endmodule
