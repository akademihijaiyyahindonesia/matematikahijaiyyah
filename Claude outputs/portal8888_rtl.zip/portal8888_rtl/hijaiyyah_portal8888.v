// hijaiyyah_portal8888.v -- the sealing FSM: four corners + portal, one HMAC
// engine time-shared, per-corner PREV chain, and a head anchor register.
//
// Sealed CORNER body (64 bytes, MSB-first) -- the exact layout Python matches:
//   [0] PORT | [1..4] T_sec(BE) | [5..8] T_tick(BE) | [9..24] SRC_IP(16)
//   [25..26] SPORT(BE) | [27..28] DPORT(BE) | [29] PROTO | [30..31] IDX(BE)
//   [32..63] PREV(32)
// Sealed PORTAL body (162 bytes):
//   [0..1] IDX_portal(BE) | [2..33] ROOT_prev(32) | [34..161] TAG_A..D (32 each)
//   TAG = HMAC(K_corner, corner body);  ROOT = HMAC(K_portal, portal body)
//   head anchor = {round, ROOT, TAG_A..D} -- a register, not host-writable.
`default_nettype none
module hijaiyyah_portal8888 (
    input  wire         clk, input wire rst_n,
    input  wire         rec_valid,
    input  wire [1:0]   rec_port,
    input  wire [31:0]  rec_tsec, input wire [31:0] rec_ttick,
    input  wire [127:0] rec_ip,
    input  wire [15:0]  rec_sport, input wire [15:0] rec_dport,
    input  wire [7:0]   rec_proto,
    input  wire [15:0]  rec_idx, input wire [15:0] rec_pidx,
    output wire         busy, output wire ready,
    input  wire [511:0] kA, input wire [511:0] kB,
    input  wire [511:0] kC, input wire [511:0] kD, input wire [511:0] kP,
    output reg  [31:0]  anc_round,
    output reg  [255:0] anc_root,
    output reg  [255:0] tagA, output reg [255:0] tagB,
    output reg  [255:0] tagC, output reg [255:0] tagD,
    output reg          round_done
);
    reg          h_start, h_finish, feed;
    reg  [511:0] h_key;
    wire         h_ready, h_idle, h_done;
    wire [255:0] h_mac;
    reg  [1295:0] sr;
    reg  [10:0]   nleft;
    wire [7:0]    byte_in  = sr[1295:1288];
    wire          take     = feed && h_ready && (nleft != 0);
    hijaiyyah_hmac u_hmac (.clk(clk), .rst_n(rst_n), .start(h_start), .key(h_key),
        .byte_valid(take), .byte_in(byte_in), .byte_ready(h_ready),
        .finish(h_finish && h_ready), .idle(h_idle), .done(h_done), .mac(h_mac));

    reg  [255:0]  prevA, prevB, prevC, prevD, root;
    reg  [3:0]    got;
    reg  [1:0]    cur;
    localparam [3:0] S_IDLE=0,S_CSTART=1,S_CSTREAM=2,S_CFIN=3,S_CWAIT=4,
                     S_PSTART=5,S_PSTREAM=6,S_PFIN=7,S_PWAIT=8;
    reg [3:0] st;
    assign busy  = (st != S_IDLE);
    assign ready = (st == S_IDLE);
    function [255:0] prev_of; input [1:0] p;
        prev_of = (p==0)?prevA:(p==1)?prevB:(p==2)?prevC:prevD; endfunction
    function [511:0] key_of; input [1:0] p;
        key_of = (p==0)?kA:(p==1)?kB:(p==2)?kC:kD; endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st<=S_IDLE; h_start<=0; h_finish<=0; feed<=0; sr<=0; nleft<=0;
            prevA<=0; prevB<=0; prevC<=0; prevD<=0; root<=0; got<=0; cur<=0;
            anc_round<=0; anc_root<=0; round_done<=0; tagA<=0; tagB<=0; tagC<=0; tagD<=0;
        end else begin
            h_start<=0; h_finish<=0; round_done<=0;
            case (st)
                S_IDLE: if (rec_valid) begin
                    cur <= rec_port;
                    sr  <= { {6'd0,rec_port}, rec_tsec, rec_ttick, rec_ip,
                             rec_sport, rec_dport, rec_proto, rec_idx,
                             prev_of(rec_port), {(1296-512){1'b0}} };
                    nleft <= 11'd64; h_key <= key_of(rec_port);
                    h_start <= 1'b1; st <= S_CSTART;
                end
                S_CSTART: begin feed<=1'b1; st<=S_CSTREAM; end     // engine leaves idle
                S_CSTREAM: begin
                    if (take) begin sr<={sr[1287:0],8'd0}; nleft<=nleft-11'd1; end
                    if (nleft==0) begin feed<=1'b0; st<=S_CFIN; end
                end
                S_CFIN: if (h_ready) begin h_finish<=1'b1; st<=S_CWAIT; end
                S_CWAIT: if (h_done) begin
                    case (cur)
                      0: begin prevA<=h_mac; tagA<=h_mac; end
                      1: begin prevB<=h_mac; tagB<=h_mac; end
                      2: begin prevC<=h_mac; tagC<=h_mac; end
                      default: begin prevD<=h_mac; tagD<=h_mac; end
                    endcase
                    if ((got | (4'b0001<<cur)) == 4'b1111) begin got<=4'b0000; st<=S_PSTART; end
                    else begin got <= got | (4'b0001<<cur); st<=S_IDLE; end
                end
                S_PSTART: begin
                    sr <= { rec_pidx, root, prevA, prevB, prevC, prevD };
                    nleft <= 11'd162; h_key <= kP; h_start<=1'b1; st<=S_PSTREAM; feed<=1'b0;
                end
                S_PSTREAM: begin
                    if (!feed) feed<=1'b1;                        // one-cycle engine warmup
                    else begin
                        if (take) begin sr<={sr[1287:0],8'd0}; nleft<=nleft-11'd1; end
                        if (nleft==0) begin feed<=1'b0; st<=S_PFIN; end
                    end
                end
                S_PFIN: if (h_ready) begin h_finish<=1'b1; st<=S_PWAIT; end
                S_PWAIT: if (h_done) begin
                    root<=h_mac; anc_root<=h_mac; anc_round<=anc_round+32'd1;
                    round_done<=1'b1; st<=S_IDLE;
                end
                default: st<=S_IDLE;
            endcase
        end
    end
endmodule
`default_nettype wire
