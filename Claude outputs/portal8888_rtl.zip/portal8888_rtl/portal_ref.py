#!/usr/bin/env python3
"""Reference for hijaiyyah_portal8888.v: compute TAG_A..D and ROOT for one round,
byte-exact to the RTL layout, and emit the testbench vectors."""
import hmac, hashlib, struct, random
rng = random.Random(20261001)
# four corner keys + portal key, 32 bytes each (RTL gets them zero-padded to 64)
K = {c: rng.randbytes(32) for c in "ABCDP"}
def mac(key, body): return hmac.new(key, body, hashlib.sha256).digest()
# one record per corner A,B,C,D
recs = []
for i, c in enumerate("ABCD"):
    recs.append(dict(port=i, tsec=1700000000+i, ttick=i*1000,
                     ip=bytes([203,0,113,10+i])+bytes(12),   # v4-ish in 16B field
                     sport=51000+i, dport=22, proto=6, idx=100+i))
prev = {0:bytes(32),1:bytes(32),2:bytes(32),3:bytes(32)}
tags = {}
for r in recs:
    body = (bytes([r["port"]]) + struct.pack(">II", r["tsec"], r["ttick"]) + r["ip"]
            + struct.pack(">HHB", r["sport"], r["dport"], r["proto"])
            + struct.pack(">H", r["idx"]) + prev[r["port"]])
    assert len(body) == 64, len(body)
    t = mac(K["ABCD"[r["port"]]], body)
    tags[r["port"]] = t; prev[r["port"]] = t
PIDX = 7
root_prev = bytes(32)
pbody = struct.pack(">H", PIDX) + root_prev + tags[0]+tags[1]+tags[2]+tags[3]
assert len(pbody) == 162, len(pbody)
root = mac(K["P"], pbody)

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "vec":
        # keys as 512-bit hex (32B key in high bytes)
        for c in "ABCDP":
            print(f"K{c} {(K[c]+bytes(32)).hex()}")
        for r in recs:
            print(f"REC {r['port']} {r['tsec']:08x} {r['ttick']:08x} {r['ip'].hex()} "
                  f"{r['sport']:04x} {r['dport']:04x} {r['proto']:02x} {r['idx']:04x}")
        print(f"PIDX {PIDX:04x}")
        for i in range(4): print(f"TAG {i} {tags[i].hex()}")
        print(f"ROOT {root.hex()}")
    else:
        for i in range(4): print(f"TAG_{'ABCD'[i]} = {tags[i].hex()}")
        print(f"ROOT   = {root.hex()}")
