# Integrasi HMAC-SHA256 perangkat keras (Ka'bah lapis 3) — serah terima untuk agen VS Code

Nama berkas disetujui pemilik pada 1 Oktober 2026. Satu commit untuk HMAC.
Perbaikan `device_identity()` dibuat sebagai commit terpisah (K4).

## Berkas baru

| berkas | isi |
|---|---|
| `rtl/hijaiyyah_sha256_core.v` | kompresi SHA-256, 1 ronde per clock, 66 clock per blok |
| `rtl/hijaiyyah_sha256_stream.v` | aliran byte, padding, panjang, dan blok prefiks |
| `rtl/hijaiyyah_hmac.v` | HMAC-SHA256, kunci ≤ 64 byte |
| `rtl/fpga/gowin/hijaiyyah_hmac_gowin_top.v` | wrapper 10 pin, UART 115200 |
| `rtl/tb/tb_hijaiyyah_sha256_stream.v`, `tb_hijaiyyah_hmac.v`, `tb_hijaiyyah_hmac_gowin_top.v` | tiga bench; masing-masing `$fatal` bila gagal dan mencetak `SEMUA LULUS (N pemeriksaan)` |
| `rtl/tb/gen_hmac_vectors.py`, `rtl/tb/sha256_vectors.txt`, `rtl/tb/hmac_vectors.txt` | vektor emas, dibangkitkan dengan seed tetap sehingga bisa direproduksi |
| `rtl/scripts/hmac_uart_test.py` | uji papan; pembandingnya `hijaiyyah.crypto.signing.sign_bytes` |
| `tests/test_integrity/test_hmac_rtl.py` | 5 tes: ketiga bench, 10 pin, dan skrip memakai `sign_bytes` |

Satu berkas yang diubah: `rtl/fpga/gowin/Makefile`, ditambah target `sim_hmac`,
`hmac_synth`, `hmac_bitstream`, dan `hmac_flash`, dengan pola yang sama
seperti `kabah_*`.

## Yang sudah dijalankan di sandbox (bukan toolchain Mac)

oss-cad-suite 2026-09-30: Yosys 0.69+158 dan Icarus 14.0-devel.

- `make sim_hmac`:
  - sha256_stream **155/155**
  - hmac **68/68**
  - wrapper lewat UART **10/10**
- Sabotase: satu bit di satu konstanta K (`K[17]` diubah `…86` menjadi `…87`)
  membuat **155 gagal** dan `make` keluar dengan exit 2. Berkas dipulihkan
  identik.
- `make hmac_bitstream`, exit 0. Hasilnya: IOB 10, LUT4 5.158 (24%),
  DFF 3.603 (23%), ALU 594, BSRAM 0.
- Fmax **tidak dikutip**. Jalur kritis sesudah routing adalah enable LED,
  bukan jalur penjumlah ronde SHA-256.
- Kelima tes di `test_hmac_rtl.py` lulus, dijalankan tanpa pytest karena
  sandbox tidak punya pytest.
- Verilator `-Wall`: bersih untuk ketiga modul inti. Pada wrapper muncul
  peringatan yang juga ada pada pola reset `hijaiyyah_kabah_gowin_top.v` dan
  pada `hcpu_uart_tx.v`. Peringatan itu bukan dari kode baru.

## Konsekuensi yang harus ditangani di gerbang (K6), dan satu keputusan pemilik

1. **Sidik jari HCPU akan berubah.** `FINGERPRINTED` di
   `tests/test_integrity/test_place_and_route.py` memuat `rtl/*.v`, jadi
   berkas baru di `rtl/` mengubah hash HCPU. Padahal sintesis HCPU hanya
   membaca `hcpu_*.v` (`SOURCES` di Makefile), sehingga bitstream HCPU tidak
   tersentuh. **Keputusan pemilik:**
   - (a) jalankan ulang PnR HCPU di Mac lalu cap sidik jarinya. Angkanya
     seharusnya identik, dan itu sekaligus bukti K6; atau
   - (b) persempit `FINGERPRINTED` ke sumber HCPU. Ini mengubah desain tes.
2. `tests/test_integrity/test_recipe_folders.py` menghitung
   `Modul RTL Ka'bah` (+3) dan `Testbench RTL` (+3). Dokumen yang mengutip
   angka ini perlu diperbarui.
3. Jumlah tes bertambah 5. Sapu dengan batas angka
   `(?<![\d.])5\.991(?!\d)` sesuai aturan no. 10.
4. Hitungan di `NUI/GRAPH.md` dan `NUI/LAYERS.md` diukur ulang dengan alat
   graf.
5. Bench anti-yatim (`test_sbox_logic.py`): ketiga bench disebut secara
   literal di `test_hmac_rtl.py`.
6. Ketiga bench sengaja **tidak** dimasukkan ke `make -C rtl/tb all`, sama
   seperti `sim_kabah`. Karena itu total asersi RTL (408 di 39 testbench)
   tidak bergeser.

## Uji papan (setelah gerbang hijau)

```sh
make -C rtl/fpga/gowin sim_hmac hmac_bitstream      # bangun ulang dengan toolchain Mac
openFPGALoader -b tangnano20k -m rtl/fpga/gowin/hijaiyyah_hmac_gowin_top.fs
python3 rtl/scripts/hmac_uart_test.py /dev/cu.usbserial-20250303171 --random 200
```

Lulus bila `RESULT: 207 PASS, 0 FAIL, of 207`. Ini uji laboratorium yang
dijalankan manusia atas perintah pemilik, bukan tindakan otonom NUI. Tabel
7.4 tidak berubah.

## Commit terpisah: `device_identity()` (`rtl/scripts/burn_in_capture.py`)

Cacatnya terukur di `08f1e36`: `info.device == port` tidak pernah cocok,
karena `list_ports.comports()` di Mac hanya memuat `/dev/cu.*`, sedangkan
capture diberi `/dev/tty.*`. Tambalannya: `/dev/tty.X` dan `/dev/cu.X`
dianggap satu perangkat. Contohnya:

```python
def _same_device(a: str, b: str) -> bool:
    """/dev/tty.X and /dev/cu.X are one device on macOS (dial-in / call-out)."""
    def stem(p: str) -> str:
        name = p.rsplit("/", 1)[-1]
        for prefix in ("tty.", "cu."):
            if name.startswith(prefix):
                return name[len(prefix):]
        return name
    return a == b or (a.startswith("/dev/") and b.startswith("/dev/")
                      and stem(a) == stem(b))
```

Lalu `if info.device == port:` diganti `if _same_device(info.device, port):`.
Tambahkan tes dengan `list_ports.comports` palsu yang hanya memuat
`/dev/cu.usbserial-X` dan port `/dev/tty.usbserial-X`: `serial_number` harus
terekam. Tambahkan juga tes bahwa `/dev/ttyUSB0` tidak cocok dengan
`/dev/cu.USB0`, karena di Linux tidak ada awalan `tty.`.
