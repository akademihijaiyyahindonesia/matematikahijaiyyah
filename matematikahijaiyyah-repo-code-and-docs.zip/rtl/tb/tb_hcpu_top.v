// ============================================================================
// HCPU Integration Testbench — tb_hcpu_top.v (Tier 1.5)
// Tests forwarding, Data RAM, and zero-NOP programs
// (c) 2026 Maulana Amratulloh — HM-28-v1.2-HC18D
// ============================================================================

`include "hcpu_pkg.vh"

module tb_hcpu_top;

    reg clk, rst_n;
    wire uart_tx, halted, guard_led;

    // ── Instruction memory (testbench-provided) ─────────────────
    // BRAM-style: registered read with 1-cycle latency + clock enable.
    // The fetch stage (hcpu_fetch.v) expects address on cycle N,
    // data valid on cycle N+1 — matching FPGA BRAM behavior.
    // imem_ce gates the output register: during pipeline stalls,
    // the BRAM holds its output to prevent in-flight data loss.
    reg [`ILEN-1:0] imem [0:`CODE_DEPTH-1];
    wire [`CODE_ADDR_W-1:0] imem_addr;
    wire imem_ce;
    reg  [`ILEN-1:0] imem_data_r;
    wire [`ILEN-1:0] imem_data;
    always @(posedge clk)
        if (imem_ce)
            imem_data_r <= imem[imem_addr];
    assign imem_data = imem_data_r;

    // ── DUT ─────────────────────────────────────────────────────
    hcpu_top #(
        .CLK_HZ(50_000_000),
        .BAUD(5_000_000)  // Fast baud for simulation
    ) u_dut (
        .clk       (clk),
        .rst_n     (rst_n),
        .imem_addr (imem_addr),
        .imem_ce   (imem_ce),
        .imem_data (imem_data),
        .uart_tx   (uart_tx),
        .halted    (halted),
        .guard_led (guard_led),
        // Debug port — unused in TB (hierarchical access is OK in sim)
        .dbg_gpr_raddr (5'd0),
        .dbg_gpr_rdata (),
        .dbg_flags     ()
    );

    // ── Clock generation (100 MHz) ──────────────────────────────
    initial clk = 0;
    always #5 clk = ~clk;

    // ── Helper function ─────────────────────────────────────────
    function [`ILEN-1:0] enc;
        input [7:0]  op;
        input [3:0]  dst, s1, s2;
        input [11:0] imm;
        enc = {op, dst, s1, s2, imm};
    endfunction

    // ── Waveform dump ───────────────────────────────────────────
    initial begin
        $dumpfile("tb_hcpu_top.vcd");
        $dumpvars(0, tb_hcpu_top);
    end

    // ── Test execution ──────────────────────────────────────────
    integer i;
    integer cycle_count;
    integer pass_count, fail_count;

    initial begin
        pass_count = 0;
        fail_count = 0;

        $display("=== HCPU Integration Test (Tier 1.5 — with Forwarding) ===");

        // ═══════════════════════════════════════════════════════
        //  Program 1: Load + Guard (NO NOPs — forwarding test)
        // ═══════════════════════════════════════════════════════

        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_HLOAD, 4'd0, 4'd0, 4'd0, 12'd2);   // H0 <- Ba
        imem[1] = enc(`OP_HGRD,  4'd0, 4'd0, 4'd0, 12'd0);   // Guard H0 (uses forwarding!)
        imem[2] = enc(`OP_MOVI,  4'd0, 4'd0, 4'd0, 12'd42);  // R0 <- 42
        imem[3] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("Program 1 halted after %0d cycles", cycle_count);

        if (guard_led) begin
            $display("PASS: Guard LED is ON (Ba passes)");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: Guard LED should be ON");
            fail_count = fail_count + 1;
        end

        if (u_dut.u_regfile.gpr[0] == 32'd42) begin
            $display("PASS: R0 = 42");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: R0 = %0d (expected 42)", u_dut.u_regfile.gpr[0]);
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 2: BSM without NOPs (forwarding stress test)
        // ═══════════════════════════════════════════════════════

        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_HLOAD, 4'd0, 4'd0, 4'd0, 12'd2);   // H0 <- Ba
        imem[1] = enc(`OP_HLOAD, 4'd1, 4'd0, 4'd0, 12'd12);  // H1 <- Sin
        imem[2] = enc(`OP_HCADD, 4'd2, 4'd0, 4'd1, 12'd0);   // H2 <- H0+H1
        imem[3] = enc(`OP_HLOAD, 4'd3, 4'd0, 4'd0, 12'd24);  // H3 <- Mim
        imem[4] = enc(`OP_HCADD, 4'd2, 4'd2, 4'd3, 12'd0);   // H2 <- H2+H3
        imem[5] = enc(`OP_HGRD,  4'd0, 4'd2, 4'd0, 12'd0);   // Guard H2
        imem[6] = enc(`OP_HNRM2, 4'd0, 4'd2, 4'd0, 12'd0);   // R0 <- ||H2||^2
        imem[7] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 2 (BSM no NOPs) halted after %0d cycles", cycle_count);
        $display("H2[Theta] = %0d (expected 10)", u_dut.u_regfile.hreg[2][7:0]);
        $display("Guard LED = %0d (expected 1)", guard_led);
        $display("R0 (||BSM||^2) = %0d (expected 112)", u_dut.u_regfile.gpr[0]);

        if (u_dut.u_regfile.hreg[2][7:0] == 8'd10) begin
            $display("PASS: BSM Theta = 10");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: BSM Theta != 10");
            fail_count = fail_count + 1;
        end

        if (u_dut.u_regfile.gpr[0] == 32'd112) begin
            $display("PASS: ||BSM||^2 = 112");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: ||BSM||^2 = %0d (expected 112)", u_dut.u_regfile.gpr[0]);
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 3: Loop (NO NOPs — forwarding test)
        // ═══════════════════════════════════════════════════════

        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_MOVI,  4'd0, 4'd0, 4'd0, 12'd0);   // R0 <- 0
        imem[1] = enc(`OP_MOVI,  4'd1, 4'd0, 4'd0, 12'd3);   // R1 <- 3
        // loop: (addr 2)
        imem[2] = enc(`OP_ADDI,  4'd0, 4'd0, 4'd0, 12'd1);   // R0++
        imem[3] = enc(`OP_CMP,   4'd0, 4'd0, 4'd1, 12'd0);   // CMP R0, R1
        imem[4] = enc(`OP_JNE,   4'd0, 4'd0, 4'd0, 12'hFFE); // JNE -2 (-> addr 2)
        imem[5] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 100) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 3 (loop no NOPs) halted after %0d cycles", cycle_count);

        if (u_dut.u_regfile.gpr[0] == 32'd3) begin
            $display("PASS: R0 = 3 (loop counted correctly)");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: R0 = %0d (expected 3)", u_dut.u_regfile.gpr[0]);
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 4: Data RAM STORE + LOAD test
        // ═══════════════════════════════════════════════════════

        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_MOVI,  4'd1, 4'd0, 4'd0, 12'd99);    // R1 <- 99
        imem[1] = enc(`OP_MOVI,  4'd2, 4'd0, 4'd0, 12'd0);     // R2 <- 0 (base addr)
        imem[2] = enc(`OP_NOP,   4'd0, 4'd0, 4'd0, 12'd0);     // pipeline settle
        imem[3] = enc(`OP_STORE, 4'd0, 4'd1, 4'd2, 12'd0);     // MEM[R2+0] <- R1
        imem[4] = enc(`OP_MOVI,  4'd1, 4'd0, 4'd0, 12'd0);     // R1 <- 0 (clear)
        imem[5] = enc(`OP_NOP,   4'd0, 4'd0, 4'd0, 12'd0);     // pipeline settle
        imem[6] = enc(`OP_LOAD,  4'd3, 4'd2, 4'd0, 12'd0);     // R3 <- MEM[R2+0]
        imem[7] = enc(`OP_NOP,   4'd0, 4'd0, 4'd0, 12'd0);     // Let LOAD finish
        imem[8] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 4 (Data RAM) halted after %0d cycles", cycle_count);

        if (u_dut.u_regfile.gpr[3] == 32'd99) begin
            $display("PASS: R3 = 99 (STORE/LOAD round-trip)");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: R3 = %0d (expected 99)", u_dut.u_regfile.gpr[3]);
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 5: Negative Guard Audit (test_negative)
        // ═══════════════════════════════════════════════════════
        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_HLOAD, 4'd0, 4'd0, 4'd0, 12'd31);  // H0 <- Corrupt index 31
        imem[1] = enc(`OP_HGRD,  4'd0, 4'd0, 4'd0, 12'd0);   // Guard Check
        imem[2] = enc(`OP_JNGD,  4'd0, 4'd0, 4'd0, 12'd2);   // If Failed (Guard=0), jump +2 -> addr 4
        imem[3] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);   // (Fail case) Halt immediately
        imem[4] = enc(`OP_MOVI,  4'd1, 4'd0, 4'd0, 12'd200); // (Pass case) R1 <- 200
        imem[5] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 5 (Negative Guard) halted after %0d cycles", cycle_count);

        if (u_dut.u_regfile.gpr[1] == 32'd200) begin
            $display("PASS: Guard correctly FAIL-BRANCHED on corrupt vector.");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: Guard did NOT fail-branch! R1 = %0d", u_dut.u_regfile.gpr[1]);
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 6: Load-Use Hazard Stall Protection
        // ═══════════════════════════════════════════════════════
        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_MOVI,  4'd2, 4'd0, 4'd0, 12'd5);     // R2 <- 5 
        imem[1] = enc(`OP_MOVI,  4'd3, 4'd0, 4'd0, 12'd10);    // R3 <- 10 (Mem Base)
        imem[2] = enc(`OP_STORE, 4'd0, 4'd2, 4'd3, 12'd0);     // MEM[10] <- R2 (5)
        imem[3] = enc(`OP_MOVI,  4'd1, 4'd0, 4'd0, 12'd0);     // R1 <- 0 (clear before load)
        imem[4] = enc(`OP_NOP,   4'd0, 4'd0, 4'd0, 12'd0);     // Bubble
        imem[5] = enc(`OP_LOAD,  4'd1, 4'd3, 4'd0, 12'd0);     // R1 <- MEM[10] (5)
        imem[6] = enc(`OP_ADD,   4'd4, 4'd1, 4'd2, 12'd0);     // R4 <- R1 + R2 = 5 + 5 = 10 (DEPENDENCY!)
        imem[7] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 6 (Load-Use Stall) halted after %0d cycles", cycle_count);

        if (u_dut.u_regfile.gpr[4] == 32'd10) begin
            $display("PASS: Load-Use stall resolved correctly! R4 = 10.");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: Load-Use pipeline failed! R4 = %0d (expected 10)", u_dut.u_regfile.gpr[4]);
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 7: HISAB HPACK + HCRC (Protocol serialization)
        // ═══════════════════════════════════════════════════════
        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        // Ba = ROM index 2
        // Expected: pack_word0 = 0x00010120, CRC32 = 0x9A3115CC
        imem[0] = enc(`OP_HLOAD, 4'd0, 4'd0, 4'd0, 12'd2);   // H0 <- Ba
        // S2 selects the word. Checking only word 0 left the other two
        // unreachable: pack_word1 and pack_word2 were wired to the top level
        // and never read, so the processor emitted four bytes of a nine-byte
        // frame and the test could not tell.
        imem[1] = enc(`OP_HPACK, 4'd0, 4'd0, 4'd0, 12'd0);   // R0 <- word0
        imem[2] = enc(`OP_HCRC,  4'd1, 4'd0, 4'd0, 12'd0);   // R1 <- CRC32
        imem[3] = enc(`OP_HPACK, 4'd2, 4'd0, 4'd1, 12'd0);   // R2 <- word1
        imem[4] = enc(`OP_HPACK, 4'd3, 4'd0, 4'd2, 12'd0);   // R3 <- word2
        imem[5] = enc(`OP_HPACK, 4'd4, 4'd0, 4'd5, 12'd0);   // R4 <- 0 (no word 5)
        imem[6] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 7 (HISAB HPACK+HCRC) halted after %0d cycles", cycle_count);
        $display("R0 (pack_word0) = 0x%08X (expected 0x00010120)", u_dut.u_regfile.gpr[0]);
        $display("R1 (CRC32)      = 0x%08X (expected 0x9A3115CC)", u_dut.u_regfile.gpr[1]);

        if (u_dut.u_regfile.gpr[0] == 32'h00010120) begin
            $display("PASS: HPACK pack_word0 = Ba golden value");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: HPACK pack_word0 mismatch!");
            fail_count = fail_count + 1;
        end

        $display("R2 (word1) = 0x%08X  R3 (word2) = 0x%08X  R4 (word5) = 0x%08X",
                 u_dut.u_regfile.gpr[2], u_dut.u_regfile.gpr[3],
                 u_dut.u_regfile.gpr[4]);

        if (u_dut.u_regfile.gpr[2] == 32'h11000001 &&
            u_dut.u_regfile.gpr[3] == 32'h00003F10 &&
            u_dut.u_regfile.gpr[4] == 32'h00000000) begin
            $display("PASS: HPACK selects all three words, and only three");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: HPACK word select broken");
            fail_count = fail_count + 1;
        end

        if (u_dut.u_regfile.gpr[1] == 32'h9A3115CC) begin
            $display("PASS: HCRC CRC32 = Ba golden value");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: HCRC CRC32 mismatch!");
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 8: Stack PUSH + POP (LIFO order)
        // ═══════════════════════════════════════════════════════
        //  PUSH/POP had no coverage at all, which meant the stack could be
        //  rewritten without a single test noticing. Pushes three values and
        //  pops them back; correct LIFO order is the assertion.

        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0]  = enc(`OP_MOVI, 4'd1, 4'd0, 4'd0, 12'd11);   // R1 <- 11
        imem[1]  = enc(`OP_MOVI, 4'd2, 4'd0, 4'd0, 12'd22);   // R2 <- 22
        imem[2]  = enc(`OP_MOVI, 4'd3, 4'd0, 4'd0, 12'd33);   // R3 <- 33
        imem[3]  = enc(`OP_NOP,  4'd0, 4'd0, 4'd0, 12'd0);
        imem[4]  = enc(`OP_PUSH, 4'd0, 4'd1, 4'd0, 12'd0);    // push 11
        imem[5]  = enc(`OP_PUSH, 4'd0, 4'd2, 4'd0, 12'd0);    // push 22
        imem[6]  = enc(`OP_PUSH, 4'd0, 4'd3, 4'd0, 12'd0);    // push 33
        imem[7]  = enc(`OP_NOP,  4'd0, 4'd0, 4'd0, 12'd0);
        imem[8]  = enc(`OP_POP,  4'd4, 4'd0, 4'd0, 12'd0);    // R4 <- 33
        imem[9]  = enc(`OP_NOP,  4'd0, 4'd0, 4'd0, 12'd0);
        imem[10] = enc(`OP_POP,  4'd5, 4'd0, 4'd0, 12'd0);    // R5 <- 22
        imem[11] = enc(`OP_NOP,  4'd0, 4'd0, 4'd0, 12'd0);
        imem[12] = enc(`OP_POP,  4'd6, 4'd0, 4'd0, 12'd0);    // R6 <- 11
        imem[13] = enc(`OP_NOP,  4'd0, 4'd0, 4'd0, 12'd0);
        imem[14] = enc(`OP_HALT, 4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 60) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 8 (Stack PUSH/POP) halted after %0d cycles", cycle_count);
        $display("R4 = %0d (expected 33), R5 = %0d (expected 22), R6 = %0d (expected 11)",
                 u_dut.u_regfile.gpr[4], u_dut.u_regfile.gpr[5], u_dut.u_regfile.gpr[6]);

        if (u_dut.u_regfile.gpr[4] == 32'd33 &&
            u_dut.u_regfile.gpr[5] == 32'd22 &&
            u_dut.u_regfile.gpr[6] == 32'd11) begin
            $display("PASS: stack returned 33, 22, 11 in LIFO order");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: stack LIFO order broken");
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 9: CGET — read one codex component
        // ═══════════════════════════════════════════════════════
        //  Until CGET existed nothing could get Theta, N, K or Q out of an
        //  H-Reg: the frozen table has no AND, no shift and no DIV, and HPACK
        //  cannot be unpacked. Haa is the sharpest probe — Theta=8 and Qc=2
        //  are the largest values in the sealed table, and an index past 17
        //  names no component at all.
        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0] = enc(`OP_HLOAD, 4'd0, 4'd0, 4'd0, 12'd27);  // H0 <- Haa
        imem[1] = enc(`OP_CGET,  4'd1, 4'd0, 4'd0, 12'd0);   // R1 <- Theta = 8
        imem[2] = enc(`OP_CGET,  4'd2, 4'd0, 4'd0, 12'd13);  // R2 <- Qc    = 2
        imem[3] = enc(`OP_CGET,  4'd3, 4'd0, 4'd0, 12'd16);  // R3 <- A_Q   = 2
        // The out-of-range probe loads Ba, not Haa, and asks for index 99.
        // calu_index is five bits, so 99 truncates to 3 — and Ba's component
        // 3 is Nd = 1, not 0. Probing Haa here proved nothing: its component
        // 3 is zero, so removing the bound left the answer unchanged and the
        // test green.
        imem[4] = enc(`OP_HLOAD, 4'd1, 4'd0, 4'd0, 12'd2);   // H1 <- Ba
        imem[5] = enc(`OP_CGET,  4'd4, 4'd1, 4'd0, 12'd99);  // R4 <- 0, not Nd
        imem[6] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 50) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 9 (CGET) halted after %0d cycles", cycle_count);
        $display("R1=%0d R2=%0d R3=%0d R4=%0d (expected 8, 2, 2, 0)",
                 u_dut.u_regfile.gpr[1], u_dut.u_regfile.gpr[2],
                 u_dut.u_regfile.gpr[3], u_dut.u_regfile.gpr[4]);

        if (u_dut.u_regfile.gpr[1] == 32'd8 &&
            u_dut.u_regfile.gpr[2] == 32'd2 &&
            u_dut.u_regfile.gpr[3] == 32'd2 &&
            u_dut.u_regfile.gpr[4] == 32'd0) begin
            $display("PASS: CGET read Haa component for component");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: CGET returned the wrong components");
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 10: CSET — write one codex component
        // ═══════════════════════════════════════════════════════
        //  The write half of CGET. What can go wrong is not the component it
        //  names but the seventeen it does not: CSET reads the register it
        //  writes, so a stale copy would carry back whatever H0 held before.
        //  Two CSETs to the same H-Reg back to back put that on the
        //  forwarding path, where the register file still holds the old
        //  value -- the write is two stages from committing.
        //
        //  Ba is [2,0,0,1,0,1,0,0,0,1,0,0,0,0,1,1,1,0]: component 4 is Kp = 0
        //  and component 5 is Kx = 1, so both writes change what was there.
        //  H2 rather than H0 on purpose -- with DST = 0 the forwarding
        //  comparison would be right by accident, since the unused S2 field
        //  is zero too, and a broken bypass would look correct.
        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0]  = enc(`OP_HLOAD, 4'd2, 4'd0, 4'd0, 12'd2);   // H2 <- Ba
        imem[1]  = enc(`OP_MOVI,  4'd1, 4'd0, 4'd0, 12'd5);   // R1 <- 5
        imem[2]  = enc(`OP_MOVI,  4'd2, 4'd0, 4'd0, 12'd6);   // R2 <- 6
        imem[3]  = enc(`OP_CSET,  4'd2, 4'd1, 4'd0, 12'd4);   // H2[Kp] <- 5
        imem[4]  = enc(`OP_CSET,  4'd2, 4'd2, 4'd0, 12'd5);   // H2[Kx] <- 6
        imem[5]  = enc(`OP_CGET,  4'd3, 4'd2, 4'd0, 12'd4);   // R3 <- 5
        imem[6]  = enc(`OP_CGET,  4'd4, 4'd2, 4'd0, 12'd5);   // R4 <- 6
        imem[7]  = enc(`OP_CGET,  4'd5, 4'd2, 4'd0, 12'd0);   // R5 <- Theta = 2
        imem[8]  = enc(`OP_CGET,  4'd6, 4'd2, 4'd0, 12'd3);   // R6 <- Nd    = 1
        // An index past 17 names no component, and 99 is the sharp probe: its
        // low five bits are 3, so a machine that truncated first would write
        // Sin's component 3 instead of writing nothing. Same trap CGET fell
        // into, from the other side.
        imem[9]  = enc(`OP_HLOAD, 4'd1, 4'd0, 4'd0, 12'd12);  // H1 <- Sin
        imem[10] = enc(`OP_MOVI,  4'd7, 4'd0, 4'd0, 12'd9);   // R7 <- 9
        imem[11] = enc(`OP_CSET,  4'd1, 4'd7, 4'd0, 12'd99);  // writes nothing
        imem[12] = enc(`OP_CGET,  4'd8, 4'd1, 4'd0, 12'd3);   // R8 <- 0, not 9
        imem[13] = enc(`OP_CGET,  4'd9, 4'd1, 4'd0, 12'd0);   // R9 <- Sin Theta = 4
        imem[14] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 80) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 10 (CSET) halted after %0d cycles", cycle_count);
        $display("R3=%0d R4=%0d R5=%0d R6=%0d R8=%0d R9=%0d (expected 5, 6, 2, 1, 0, 4)",
                 u_dut.u_regfile.gpr[3], u_dut.u_regfile.gpr[4],
                 u_dut.u_regfile.gpr[5], u_dut.u_regfile.gpr[6],
                 u_dut.u_regfile.gpr[8], u_dut.u_regfile.gpr[9]);

        if (u_dut.u_regfile.gpr[3] == 32'd5 &&
            u_dut.u_regfile.gpr[4] == 32'd6 &&
            u_dut.u_regfile.gpr[5] == 32'd2 &&
            u_dut.u_regfile.gpr[6] == 32'd1 &&
            u_dut.u_regfile.gpr[8] == 32'd0 &&
            u_dut.u_regfile.gpr[9] == 32'd4) begin
            $display("PASS: CSET wrote the components it named and kept the rest");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: CSET lost a component or wrote the wrong one");
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        //  Program 11: the rest of the codex block -- CMOV, CZERO, CEQ,
        //  CRHO, CU, CMOD4
        // ═══════════════════════════════════════════════════════
        //  Haa is the sharpest single letter for the three derived
        //  quantities: Theta = 8 and Qc = 2, so U = 4*2 = 8, rho = 0, and
        //  8 mod 4 = 0 -- the Mod-4 gate's answer for a MainPath that may
        //  close. CDOT is NOT here: its fourteen multipliers put the bare
        //  hcpu_gowin_top slot past what nextpnr can place, so it stays
        //  software-only until the owner decides otherwise (OFF.md).
        for (i = 0; i < `CODE_DEPTH; i = i + 1)
            imem[i] = {`OP_NOP, 24'h000000};

        imem[0]  = enc(`OP_HLOAD, 4'd0, 4'd0, 4'd0, 12'd27);  // H0 <- Haa
        imem[1]  = enc(`OP_HLOAD, 4'd1, 4'd0, 4'd0, 12'd2);   // H1 <- Ba
        imem[2]  = enc(`OP_CMOV,  4'd2, 4'd0, 4'd0, 12'd0);   // H2 <- H0
        imem[3]  = enc(`OP_CU,    4'd1, 4'd0, 4'd0, 12'd0);   // R1 <- U    = 8
        imem[4]  = enc(`OP_CRHO,  4'd2, 4'd0, 4'd0, 12'd0);   // R2 <- rho  = 0
        imem[5]  = enc(`OP_CMOD4, 4'd3, 4'd0, 4'd0, 12'd0);   // R3 <- 8%4  = 0
        // CZERO is checked as the IDENTITY OF THE MONOID, not against another
        // CZERO. Comparing two zeroed registers was the first shape here and
        // it was blind: a CZERO that writes the same wrong vector twice
        // compares equal to itself, and a sabotage that put 1 in component 0
        // passed. Adding zero to a letter cannot hide that -- HCADD touches
        // all eighteen components and CEQ compares all 144 bits, so any
        // non-zero component makes H5 differ from H0.
        imem[6]  = enc(`OP_CZERO, 4'd3, 4'd0, 4'd0, 12'd0);   // H3 <- 0
        imem[7]  = enc(`OP_HCADD, 4'd5, 4'd0, 4'd3, 12'd0);   // H5 <- Haa + 0
        // Equality into Z, read back the way the ISA reads any flag: a branch.
        imem[8]  = enc(`OP_MOVI,  4'd6, 4'd0, 4'd0, 12'd0);
        imem[9]  = enc(`OP_CEQ,   4'd0, 4'd2, 4'd0, 12'd0);   // H2 == H0 -> Z=1
        imem[10] = enc(`OP_JNE,   4'd0, 4'd0, 4'd0, 12'd2);   // not taken
        imem[11] = enc(`OP_MOVI,  4'd6, 4'd0, 4'd0, 12'd1);   // R6 <- 1
        imem[12] = enc(`OP_MOVI,  4'd7, 4'd0, 4'd0, 12'd0);
        imem[13] = enc(`OP_CEQ,   4'd0, 4'd0, 4'd1, 12'd0);   // Haa == Ba -> Z=0
        imem[14] = enc(`OP_JNE,   4'd0, 4'd0, 4'd0, 12'd2);   // taken -> 16
        imem[15] = enc(`OP_MOVI,  4'd7, 4'd0, 4'd0, 12'd1);   // skipped
        imem[16] = enc(`OP_MOVI,  4'd4, 4'd0, 4'd0, 12'd0);
        imem[17] = enc(`OP_CEQ,   4'd0, 4'd5, 4'd0, 12'd0);   // Haa+0 == Haa
        imem[18] = enc(`OP_JNE,   4'd0, 4'd0, 4'd0, 12'd2);   // not taken
        imem[19] = enc(`OP_MOVI,  4'd4, 4'd0, 4'd0, 12'd1);   // R4 <- 1
        imem[20] = enc(`OP_HALT,  4'd0, 4'd0, 4'd0, 12'd0);

        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;

        cycle_count = 0;
        while (!halted && cycle_count < 80) begin
            @(posedge clk);
            cycle_count = cycle_count + 1;
        end

        $display("\nProgram 11 (codex block) halted after %0d cycles", cycle_count);
        $display("R1=%0d R2=%0d R3=%0d R4=%0d R6=%0d R7=%0d (expected 8, 0, 0, 1, 1, 0)",
                 u_dut.u_regfile.gpr[1], u_dut.u_regfile.gpr[2],
                 u_dut.u_regfile.gpr[3], u_dut.u_regfile.gpr[4],
                 u_dut.u_regfile.gpr[6], u_dut.u_regfile.gpr[7]);

        if (u_dut.u_regfile.gpr[1] == 32'd8 &&
            u_dut.u_regfile.gpr[2] == 32'd0 &&
            u_dut.u_regfile.gpr[3] == 32'd0 &&
            u_dut.u_regfile.gpr[4] == 32'd1 &&
            u_dut.u_regfile.gpr[6] == 32'd1 &&
            u_dut.u_regfile.gpr[7] == 32'd0) begin
            $display("PASS: CMOV, CZERO, CEQ, CRHO, CU and CMOD4 agree with the table");
            pass_count = pass_count + 1;
        end else begin
            $display("FAIL: one of the codex-block opcodes returned the wrong value");
            fail_count = fail_count + 1;
        end

        // ═══════════════════════════════════════════════════════
        $display("\n=============================");
        $display("Total: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("=============================");
        // $fatal exits non-zero so a failing run reaches the shell and CI.
        if (fail_count > 0) $fatal(1, "*** %0d INTEGRATION TESTS FAILED ***", fail_count);
        $display("=== All integration tests complete ===");
        $finish(0);
    end

endmodule
