// hijaiyyah_wave.v — the wave's line-rate stages: bits in, findings out.
//
// Bits arrive one per clock with no byte boundary. This deserialises them at a
// given phase and drives the node counter, so a window's class and its
// recovered XOR key come out every WINDOW bytes at full rate.
//
// WHAT IS HERE AND WHAT IS NOT, because a pipeline diagram that overstates its
// own extent is the most convincing wrong thing a design can carry.
//
//   stage 1a  phase discovery      NOT here. Finding the byte boundary needs
//                                  an index-of-coincidence histogram -- 256
//                                  bins, one block RAM -- and it runs once
//                                  per stream, not per clock. Software finds
//                                  it; `phase` is an input.
//   stage 1b  deserialise at phase  here, 8 clocks per byte.
//   stage 2   classify + key        here, via hijaiyyah_node_counter.
//   stage 3   canonical report      here only as the output wires; the packing
//                                  is software.
//   stage 4   HMAC-SHA256           NOT here. There is no SHA-256 core in this
//                                  module: the HMAC core is a slot of its own
//                                  (rtl/hijaiyyah_hmac.v), not on this path,
//                                  and the findings are unauthenticated until
//                                  they are signed.
//
// So this module produces findings at line rate and does not authenticate
// them. That split is the honest one: the part that must keep up with the
// wire is here, and the part that carries the security is where it has been
// reviewed.

`default_nettype none

module hijaiyyah_wave #(
    parameter integer WINDOW = 64
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [2:0] phase,        // byte boundary, discovered in software
    input  wire       bit_valid,
    input  wire       bit_in,
    output wire       found_valid,
    output wire [1:0] found_class,
    output wire [7:0] found_key
);

    wire       byte_valid;
    wire [7:0] byte_out;

    hijaiyyah_deserialiser u_des (
        .clk(clk), .rst_n(rst_n), .phase(phase),
        .bit_valid(bit_valid), .bit_in(bit_in),
        .byte_valid(byte_valid), .byte_out(byte_out));

    // ---- stage 2: classify and recover ---------------------------------
    hijaiyyah_node_counter #(.WINDOW(WINDOW)) u_counter (
        .clk         (clk),
        .rst_n       (rst_n),
        .valid_in    (byte_valid),
        .byte_in     (byte_out),
        .valid_out   (found_valid),
        .class_out   (found_class),
        .xor_key_out (found_key)
    );

endmodule

`default_nettype wire
