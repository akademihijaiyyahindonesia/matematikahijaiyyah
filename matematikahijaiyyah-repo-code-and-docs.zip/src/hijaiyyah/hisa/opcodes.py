"""
Opcode definitions and instruction word encoding.

Bab III §3.24–3.25: H-ISA Instruction Set Architecture.

Single source of truth for the encoding: rtl/hcpu_pkg.vh.

These two halves used to disagree outright. The software side numbered HLOAD
0x01 while the RTL numbered it 0x40 — and 0x01 is the RTL's HALT, so the first
instruction of any compiled program would have stopped the processor. Of the
thirteen mnemonics both sides defined, only four agreed. They were not two
implementations of one ISA; they were two ISAs sharing a name.

The RTL encoding wins, for two reasons. It is grouped by function, so the top
nibble carries meaning. And it is the half that is verified in hardware and
destined for silicon, where a wrong number cannot be patched.

The block map is docs/HISA_SPEC.md §6.1, which the RTL already follows almost
everywhere:

    0x0_  system and control            0x60–0x6F  guards and audit
    0x1_  integer arithmetic            0x70–0x7F  crypto
    0x2_  compare and control flow      0x80–0x8F  vector math
    0x3_  memory and stack              0x90–0x9F  string operations
    0x40–0x5F  codex operations         0xA0–0xAF  I/O and debug
                                        0xB0–0xFF  reserved / error halt

Three places where the RTL departs from that document, and the RTL wins:

    0x06, 0x07   HNRM2, HDIST   the spec puts POP and CALL here
    0x32, 0x33   PUSH, POP      the spec puts LOADR and LEA here
    0x50, 0x51   HPACK, HCRC    the spec puts CAN and CAK here

Opcodes the HCPU does not implement are marked "software only" below. They run
under the HVM and the HISA machine, and sit in gaps both the RTL and the spec
leave free, so promoting one to hardware later never forces a renumbering.

tests/test_hisa/test_isa_parity.py holds this file and hcpu_pkg.vh together.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class OpCode(IntEnum):
    # ── System (0x0_) ────────────────────────────────────────────
    NOP = 0x00      # No operation
    HALT = 0x01     # Terminate
    MOV = 0x03      # Copy GPR
    MOVI = 0x04     # Load immediate into GPR

    # Hybit scalars that return to a GPR. In the 0x0_ block rather than 0x4_
    # because their result is an integer, not a hybit.
    # Return from a trap: PC <- the saved epc, and the in-trap latch clears.
    # It takes no operands -- everything it needs is in the trap unit, which
    # software reaches through the peripheral window, so no CSR instruction
    # had to be invented for it.
    ERET = 0x08     # Return from trap
    # The one crossing user mode may make. No operand field: the call number
    # and its arguments travel in registers, by convention rather than by
    # encoding, so the ABI can change without touching the instruction.
    # docs/HISA_SPEC.md already reserved 0x09 for SYSCALL, with an immediate
    # operand -- `SYSCALL #code`. The slot and the name are kept; the operand
    # is not, and the reason is mechanical: the handler cannot read the
    # immediate. Instruction memory is Harvard and write-only from the CPU's
    # side, so nothing can fetch the calling instruction, and all sixteen
    # peripheral slots are taken so there is nowhere to latch it. The call
    # number travels in a register instead, by convention rather than
    # encoding, which also lets the ABI change without touching the opcode.
    SYSCALL = 0x09
    # H-ISA v1.1. FLAGS was reachable only by the J-forms, so nothing could
    # save it -- and a context switch that cannot save a register does not
    # own it. Measured before these existed: a loop carrying one comparison,
    # swept against sixty timer deadlines, had five of them REVERSE the branch,
    # because the handler's own CMP of TRAP_CAUSE overwrote the process's.
    #
    # Both take a free slot in System & Control, the block §6.1 gives to
    # machine state, per §6.0 rule 2; the version bump is rule 4.
    FRD = 0x0A      # GPR[dst] ← FLAGS, zero-extended
    FWR = 0x0B      # FLAGS ← GPR[s1][7:0]  # Deliberate trap — ask the supervisor
    HNRM2 = 0x06    # Squared norm: ‖v₁₄‖² → GPR
    HDIST = 0x07    # Squared Euclidean distance → GPR

    # ── Integer arithmetic (0x1_) ────────────────────────────────
    ADD = 0x10      # GPR addition
    ADDI = 0x11     # GPR + immediate
    SUB = 0x12      # GPR subtraction
    MUL = 0x14      # GPR multiplication

    # ── Bitwise and shift (0xB_) ─────────────────────────────────
    #
    # Absent until now, and their absence was the blocker: an allocator needs
    # free-list bitmaps, a scheduler needs ready masks, a driver needs
    # register fields, a filesystem needs block bitmaps. None of those can be
    # written with add, subtract and multiply. Every CosmicTera module leans
    # on them too — 80 bitwise operations across four core files.
    #
    # Two decisions worth stating, because leaving either implicit is how the
    # VM and the RTL drift apart:
    #
    #   Shift amounts are masked to 5 bits. A shift of 32 or more has no
    #   natural answer on a 32-bit machine, and "undefined" means the
    #   interpreter and the silicon are free to disagree. RISC-V masks; so
    #   does this.
    #
    #   Logical immediates are ZERO-extended, unlike ADDI's which is sign-
    #   extended. `ANDI r, r, 0x0FF` must mask the low eight bits; sign
    #   extension would make it 0xFFFFF0FF, which is never what a mask means.
    AND = 0xb0      # GPR bitwise and
    OR = 0xb1       # GPR bitwise or
    XOR = 0xb2      # GPR bitwise exclusive or
    NOT = 0xb3      # GPR bitwise complement (one source)
    SHL = 0xb4      # GPR shift left, amount from a register
    SHR = 0xb5      # GPR shift right, logical, amount from a register
    ANDI = 0xb6     # GPR and immediate, zero-extended
    ORI = 0xb7      # GPR or immediate, zero-extended
    XORI = 0xb8     # GPR xor immediate, zero-extended
    SHLI = 0xb9     # GPR shift left by immediate
    SHRI = 0xBA     # GPR shift right by immediate, logical

    # ── Compare and control flow (0x2_) ──────────────────────────
    CMP = 0x20      # Compare two GPRs, set flags
    CMPI = 0x21     # Compare GPR with immediate
    JMP = 0x22      # Unconditional jump
    JEQ = 0x23      # Jump if equal
    JNE = 0x24      # Jump if not equal
    JGD = 0x29      # Jump if GUARD flag set
    JNGD = 0x2A     # Jump if GUARD flag clear
    # 0x2B–0x2F is the spec's reserved tail of this block.
    JGP = 0x2B      # Jump if guard pass          (software only)
    JGF = 0x2C      # Jump if guard fail          (software only)
    JNP = 0x2D      # Jump if not pass            (software only)
    # The spec puts CALL/RET at 0x07/0x08, which the RTL uses for HDIST and
    # for the reserved slot after it. They move here instead.
    CALL = 0x2E     # Call subroutine             (software only)
    RET = 0x2F      # Return from subroutine      (software only)

    # ── Memory and stack (0x3_) ──────────────────────────────────
    LOAD = 0x30     # GPR ← MEM[base + offset]
    STORE = 0x31    # MEM[base + offset] ← GPR
    PUSH = 0x32     # Push GPR to stack
    POP = 0x33      # Pop stack into GPR

    # ── Codex operations (0x40–0x5F) ─────────────────────────────
    HLOAD = 0x40    # Load hybit from the sealed ROM: 1-28 letters, 31-36 negative
    # Component read. HISA_SPEC.md already assigned 0x44 to CGET with
    # exactly this semantics and never implemented it; this fills that
    # slot rather than inventing a new one. Not HPROJ — 0x80 carries that
    # name for layer projection, which yields a sub-vector.
    CGET = 0x44     # GPR[dst] ← H[s1][imm], component 0–17
    # Component write, the other half of CGET. HISA_SPEC.md assigned 0x45 to
    # CSET with exactly this semantics and never implemented it either; it is
    # what hos_fs_read needs to rebuild a live H-Reg out of stored words.
    CSET = 0x45     # H[dst][imm] ← GPR[s1], component 0–17
    HCADD = 0x42    # Codex addition: dst ← src1 + src2
    # CSUB is DEFERRED rather than merely unimplemented, and the reason is not
    # effort: a difference leaves the monoid -- Domain C in Bab I §IA.1.11 --
    # so components can be negative, while an H-Reg component is an unsigned
    # byte on the hardware. What silicon should store there is the spec owner's
    # decision. Recorded in cosmictera-build/OFF.md.
    CSUB = 0x43     # Component-wise subtract     (software only, deferred)
    # The spec's C-names are canonical for everything the RTL executes: the
    # encoding's source of truth is hcpu_pkg.vh (HISA_SPEC.md §6.0), and it
    # spells them OP_CMOV, OP_CZERO, OP_CEQ, OP_CRHO, OP_CU, OP_CMOD4. The
    # V-spellings stay below as enum aliases, so code that already names them
    # keeps working; the assembler's dialect is the spec's.
    CMOV = 0x46     # H[dst] ← H[s1]
    CZERO = 0x47    # H[dst] ← 0, the identity of the monoid
    CEQ = 0x48      # FLAGS.Z ← (H[s1] == H[s2])
    # Software-only for a measured reason, not an unfinished one. An inner
    # product over fourteen components is fourteen 8×8 multipliers, and with
    # them hcpu_gowin_top reaches 16,015 LUT4 (77%) where nextpnr answers
    # "Unable to find legal placement for all cells". Without it the same slot
    # is 14,714 LUT4 (70%) and places. The blocker is named in
    # cosmictera-build/OFF.md; the decision to leave it out was the owner's.
    CDOT = 0x49     # ⟨H[s1], H[s2]⟩₁₄ → GPR   (software only; see OFF.md)
    # Left software-only on purpose: the RTL already executes these operations
    # under the names the book froze, HNRM2 (0x06) and HDIST (0x07). A second
    # encoding for one operation is the defect 7582ae5 went through the tree to
    # remove, so the decision belongs to the spec owner, not here.
    VNORM = 0x4A    # Squared norm → GPR          (software only; RTL: HNRM2)
    VDIST = 0x4B    # Squared distance → GPR      (software only; RTL: HDIST)
    CRHO = 0x4C     # GPR[dst] ← ρ(H[s1]) = Θ̂ − U, signed
    CU = 0x4D       # GPR[dst] ← U(H[s1]) = Qx + Qs + Qa + 4·Qc
    CTHETA = 0x4E   # GPR[dst] ← Θ̂(H[s1]) = H[s1][7:0]
    CMOD4 = 0x4F    # GPR[dst] ← Θ̂(H[s1]) mod 4

    HPACK = 0x50    # Nibble-pack a hybit into words
    HCRC = 0x51     # CRC32 over a packed frame
    HDOT = 0x52     # GPR[dst] ← ⟨H[s1], H[s2]⟩₁₄ (20-bit unsigned, Alternative A2)
    # 0x55–0x5F is the spec's reserved tail for future codex operations.
    HEXMT = 0x55    # Build 5×5 exomatrix         (software only)
    HDCMP = 0x56    # Decompose into (U, ρ)       (software only)
    HSER = 0x57     # Serialize to HISAB frame    (software only)
    HDES = 0x58     # Deserialize a HISAB frame   (software only)
    VSCL = 0x59     # Scalar multiply             (software only)

    # ── Guards and audit (0x60–0x6F) ─────────────────────────────
    HGRD = 0x60     # Guard check G1–G4, T1–T2 → GUARD flag
    HCHK = 0x68     # Runtime integrity check     (software only)

    # ── Crypto (0x70–0x7F) — software only ───────────────────────
    CHASH = 0x70    # Compute hash
    CSIGN = 0x72    # Sign / verify

    # ── Vector math (0x80–0x8F) — software only ──────────────────
    HPROJ = 0x80    # Project onto layer given by IMM
    VPROJ_T = 0x88  # Project to Θ
    VPROJ_N = 0x89  # Project to N
    VPROJ_K = 0x8A  # Project to K
    VPROJ_Q = 0x8B  # Project to Q

    # ── I/O and debug (0xA0–0xAF) ────────────────────────────────
    PRINT = 0xA0    # Print value from GPR
    PRINTH = 0xA1   # Print hybit with detail     (software only)
    # H-ISA v1.1. The slot and the name are v1.0's; what v1.1 added is the
    # string's shape in RAM -- one ASCII byte per 32-bit word, terminated by a
    # zero word -- and an implementation. Chosen for being checkable rather
    # than compact: no byte order to get wrong, no packing, and a terminator a
    # test can delete. §13.1.1.
    EMITS = 0xA2    # Print the string at IMM, one char per word

    # ── Error ────────────────────────────────────────────────────

    # ── Letter instructions, 0xE0–0xFB ───────────────────────────
    # One letter is the whole instruction. No register to name, no immediate
    # to write: a letter already IS a value, a function and a rate, and
    # spelling that out in operands discards what it carries.
    #
    #     HREG[0] <- HREG[0] + v(letter)
    #
    # The accumulator is implicit because there is nothing to choose, and that
    # is safe rather than merely short: the guard is closed under addition,
    # measured over all 784 pairs and 2,000 five-term sums, so a program made
    # of letters cannot leave the valid set. A word therefore computes its own
    # codex by being written -- string_integral, as instructions.
    #
    # ASCII names because hcpu_pkg.vh needs them and Verilog identifiers are
    # ASCII. The assembler takes the Arabic letter itself as an alias, which
    # is the point: `ج` is a line of source.
    #
    # 0xE0-0xFB is exactly 28 slots. 0xFC-0xFE stay free; 0xFF is HALT_ERR.
    L_ALIF     = 0xE0      # ا  Alif
    L_BA       = 0xE1      # ب  Ba
    L_TA       = 0xE2      # ت  Ta
    L_TSA      = 0xE3      # ث  Tsa
    L_JIM      = 0xE4      # ج  Jim
    L_HA       = 0xE5      # ح  Ha
    L_KHA      = 0xE6      # خ  Kha
    L_DAL      = 0xE7      # د  Dal
    L_DZAL     = 0xE8      # ذ  Dzal
    L_RA       = 0xE9      # ر  Ra
    L_ZAY      = 0xEA      # ز  Zay
    L_SIN      = 0xEB      # س  Sin
    L_SYIN     = 0xEC      # ش  Syin
    L_SHAD     = 0xED      # ص  Shad
    L_DHAD     = 0xEE      # ض  Dhad
    L_THA      = 0xEF      # ط  Tha
    L_ZHA      = 0xF0      # ظ  Zha
    L_AIN      = 0xF1      # ع  Ain
    L_GHAIN    = 0xF2      # غ  Ghain
    L_FA       = 0xF3      # ف  Fa
    L_QAF      = 0xF4      # ق  Qaf
    L_KAF      = 0xF5      # ك  Kaf
    L_LAM      = 0xF6      # ل  Lam
    L_MIM      = 0xF7      # م  Mim
    L_NUN      = 0xF8      # ن  Nun
    L_WAW      = 0xF9      # و  Waw
    L_HAA      = 0xFA      # هـ  Haa
    L_YA       = 0xFB      # ي  Ya

    HALT_ERR = 0xFF  # Halt on an unimplemented or faulting instruction

    # ── Aliases ──────────────────────────────────────────────────
    # Same value as the member above, so Python treats these as alternate
    # spellings rather than separate opcodes. Kept for source compatibility.
    # The spec's names for opcodes this file reached first.
    CLOAD = 0x40    # → HLOAD
    CADD = 0x42     # → HCADD
    VCHK = 0x60     # → HGRD
    EMIT = 0xA0     # → PRINT

    # This file's names for opcodes the spec reached first. Same operation,
    # different prefix convention; both spellings assemble.
    VMOV = 0x46     # → CMOV
    VCMP = 0x48     # → CEQ
    VDOT = 0x49     # → CDOT
    CNORM = 0x4A    # → VNORM
    CDIST = 0x4B    # → VDIST
    VRHO = 0x4C     # → CRHO
    VPROJ = 0x80    # → HPROJ
    EMITC = 0xA1    # → PRINTH

    # Ordinary synonyms.
    IADD = 0x10     # → ADD
    ISUB = 0x12     # → SUB
    IMUL = 0x14     # → MUL
    ICMP = 0x20     # → CMP
    PRINTI = 0xA0   # → PRINT   (printing an integer is what PRINT does)


# Opcodes the HCPU RTL implements. Anything outside this set runs only under
# the HVM and the HISA machine, and must not appear in a program intended for
# hardware. Kept as data so tests can check it against hcpu_pkg.vh directly.
RTL_IMPLEMENTED: frozenset[OpCode] = frozenset({
    OpCode.NOP, OpCode.HALT, OpCode.MOV, OpCode.MOVI, OpCode.ERET, OpCode.SYSCALL,
    OpCode.CALL, OpCode.RET,
    OpCode.L_ALIF, OpCode.L_BA, OpCode.L_TA, OpCode.L_TSA, OpCode.L_JIM, OpCode.L_HA, OpCode.L_KHA,
    OpCode.L_DAL, OpCode.L_DZAL, OpCode.L_RA, OpCode.L_ZAY,
    OpCode.L_SIN, OpCode.L_SYIN, OpCode.L_SHAD,
    OpCode.L_DHAD, OpCode.L_THA, OpCode.L_ZHA, OpCode.L_AIN,
    OpCode.L_GHAIN, OpCode.L_FA, OpCode.L_QAF,
    OpCode.L_KAF, OpCode.L_LAM, OpCode.L_MIM, OpCode.L_NUN, OpCode.L_WAW, OpCode.L_HAA, OpCode.L_YA,
    OpCode.HNRM2, OpCode.HDIST,
    OpCode.ADD, OpCode.ADDI, OpCode.SUB, OpCode.MUL,
    OpCode.AND, OpCode.OR, OpCode.XOR, OpCode.NOT,
    OpCode.SHL, OpCode.SHR,
    OpCode.ANDI, OpCode.ORI, OpCode.XORI, OpCode.SHLI, OpCode.SHRI,
    OpCode.CMP, OpCode.CMPI, OpCode.JMP, OpCode.JEQ, OpCode.JNE,
    OpCode.FRD, OpCode.FWR,
    OpCode.EMITS,
    OpCode.JGD, OpCode.JNGD,
    OpCode.LOAD, OpCode.STORE, OpCode.PUSH, OpCode.POP,
    OpCode.HLOAD, OpCode.CGET, OpCode.CSET, OpCode.HCADD,
    OpCode.CMOV, OpCode.CZERO, OpCode.CEQ,
    OpCode.CRHO, OpCode.CU, OpCode.CTHETA, OpCode.CMOD4,
    OpCode.HPACK, OpCode.HCRC, OpCode.HDOT,
    OpCode.HGRD,
    OpCode.PRINT,
    OpCode.HALT_ERR,
})


def is_rtl_implemented(op: int) -> bool:
    """True if the HCPU can execute this opcode; False for software-only ones."""
    try:
        return OpCode(op) in RTL_IMPLEMENTED
    except ValueError:
        return False


# ── Layer IDs for HPROJ ──────────────────────────────────────────

LAYER_THETA: int = 0
LAYER_N: int = 1
LAYER_K: int = 2
LAYER_Q: int = 3


@dataclass
class InstructionWord:
    """
    32-bit instruction word, laid out exactly as the RTL reads it:

        [31:24] opcode   [23:20] dst   [19:16] src1   [15:12] src2   [11:0] imm

    Matches `enc = {op, dst, s1, s2, imm}` in rtl/tb/tb_hcpu_top.v.
    """

    raw: int

    @property
    def opcode(self) -> int:
        return (self.raw >> 24) & 0xFF

    @property
    def dst(self) -> int:
        return (self.raw >> 20) & 0xF

    @property
    def src1(self) -> int:
        return (self.raw >> 16) & 0xF

    @property
    def src2(self) -> int:
        return (self.raw >> 12) & 0xF

    @property
    def imm(self) -> int:
        return self.raw & 0xFFF

    def disassemble(self) -> str:
        try:
            op = OpCode(self.opcode)
        except ValueError:
            return f"UNKNOWN(0x{self.opcode:02X})"
        mark = "" if op in RTL_IMPLEMENTED else "  ; software only"
        return (
            f"{op.name} dst=H{self.dst} src1=H{self.src1} "
            f"src2=H{self.src2} imm={self.imm}{mark}"
        )
